function [r]=cal_frac(l,m)

r=(2*l-1)/2/m;
end



